<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
 public function __construct()
        {
            parent::__construct();    
            header("Last-Modified: " . gmdate( "D, j M Y H:i:s" ) . " GMT"); 
            header("Expires: " . gmdate( "D, j M Y H:i:s", time() ) . " GMT"); 
            header("Cache-Control: no-store, no-cache, must-revalidate"); 
            header("Cache-Control: post-check=0, pre-check=0", FALSE);
            header("Pragma: no-cache");
            $this->load->helper(array('url','html','form','text'));
            $this->load->library(array('form_validation','upload','user_agent','session','pagination'));
             
            }
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$data['title'] = 'PT.Payung Anak Bangsa';   
        $data['main'] = 'main_welcome';
       $this->load->view('welcome_message', $data);
	}
}

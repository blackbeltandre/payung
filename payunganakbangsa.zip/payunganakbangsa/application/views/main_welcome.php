<br><div class="container">
            <div class="row">
                <h3 class="center light grey-text text-darken-3">About Us</h3>
                <div class="col div m6 light">
                   
                    <p><img src="<?php echo base_url(); ?>assets/img/pyng.jpg" width="140" heigth="80"><br>PT. Payung Anak Bangsa is a company engaged in IT Solution. As an experienced IT consultant, we can provide the right solution for all kinds of the problems in managing your IT system and enterprise architecture. We'll provide advice and include in the implementation of your system ,so that it can improve the performance of your business. 
                      We have skilled and experienced professionals in their fields.</p>
                </div>

                <div class="col div m6 light darken-3">
                     <h5>Our Solutions</h5>
                   <p>Web, Dekstop and Mobile Application.</p>
                   <div class="progress ">
                        <div class="determinate red" style="width: 90%"></div>
                    </div>

                    <p>Enterprise Network ,Server Infrastructure and DevOps Solution </p>
                    <div class="progress">
                         <div class="determinate red" style="width: 100%"></div>
                     </div>

                     <p>IT Consultant with Agile Methodology</p>
                     <div class="progress">
                          <div class="determinate red" style="width: 80%"></div>
                    </div>
               </div>
            </div>
        </div>
    </section>

    <!-- Clients -->

<!--     <div id="clients" class="parallax-container scrollspy" >-->
<!--        <div class="parallax"><img src="img/web2.jpg">-->
<!--        </div>-->
   

<!--   <div  class="container clients" >-->
<!--       <h3 class="center light grey-text text-darken-3">Who Whe're ?</h3>-->
<!--       <div class="row">-->
          

<!--           <div class="col m6 s12 center" >-->
<!--                <img src="img/index-1.jpg" width="125" heigth="120" class="circle responsive-img">-->
<!--                <p><font color="black">Hendra - Komisaris</font></p>-->
<!--            </div>-->
<!--             <div class="col m6 s12 center">-->
<!--               <img src="img/mee-1.jpg" width="125" heigth="120" class="circle responsive-img">-->
<!--               <p><font color="black">Andre - Direktur Utama</font></p>-->
<!--           </div>-->
            
<!--       </div>-->
<!--   </div>-->
<!--</div> -->

<div id="clients" class="parallax-container scrollspy" >
     <div class="parallax"><img src="<?php echo base_url(); ?>assets/img/web2.jpg">
        </div>
   <br><br>
   <div  class="container clients" >
       <h3 class="center light grey-text text-darken-3">Who Whe're ?</h3>
       <div class="row">

           <div class="col m3 s12 center">
               <img src="<?php echo base_url(); ?>assets/andre.jpg" width="80" heigth="120" class="circle responsive-img" />
               <p><font color="black">Andreas Sahabat Lumban Batu S.Kom, M.TI - Founder</font></p>
            </div>
            <div class="col m3 s12 center" >
                <img src="<?php echo base_url(); ?>assets/hendraa.png" width="100" heigth="120" class="circle responsive-img" />
                <p><font color="black">Hendra S.Kom,CCNA - Co - Founder</font></p>
            </div>
           <div class="col m3 s12 center">
               <img src="<?php echo base_url(); ?>assets/bb.jpg" width="90" heigth="120" class="circle responsive-img" />
               <p><font color="black">Bobi Osvaldo S.E - CFO</font></p>
           </div>
             <div class="col m3 s12 center">
          <img src="<?php echo base_url(); ?>assets/slam.jpg" width="90" heigth="120"
            class="circle responsive-img" />
          <p>
            <font color="black">Slamet Rianto S.Kom - CTO</font>
          </p>
        </div>
       </div>
   </div>
</div> 

<button onclick="topFunction()" id="myBtn" title="Go to top"><img src="<?php echo base_url(); ?>assets/top.png" width="40" heigth="40"></button>

<!-- services -->
    <section id="services" class="services grey lighten-4 scrollspy" >
      <div class="container">
        <div class="row"><br>
          <h3 class="light center gray-text text-darken-3">Our Services</h3>
          <div class="col m4 s12 white darken-3">
          <div class="card-panel center">
            <i class="material-icons medium">phone_android</i>
             <h5>Application Development</h5>
          </div>
        </div>

        <div class="col m4 s12 white darken-3">
            <div class="card-panel center">
              <i class="material-icons medium">developer_mode</i>
               <h5>Network, Server Infrastructure ,DevOps</h5>
            </div>
          </div>
          <div class="col m4 s12 white darken-3">
              <div class="card-panel center">
                <i class="material-icons medium">laptop_windows</i>
                <h5>IT</br> Consultant</h5>
              </div>
            </div>
        </div>
     </div>
</section>

        <!-- portfolio -->
        <br>
        <section id="portfolio" class="portfolio scrollspy" >
          <div class="container"><br>
            <h3 class="light center gray-text text-darken-3">Portfolio</h3>
            <div class="row center">
              <h5 class="light center gray-text text-darken-3">Why you should trust work with us ?</h5>
              <p>We experience as IT Consultant to build the great database,application,network and infrastructure on government, corporate,education & college,community,foundation,cyber on national and international project.</p>
              <?php 
$link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 
                "https" : "http") . "://" . $_SERVER['HTTP_HOST'] .  
                $_SERVER['REQUEST_URI']; 
  //echo $link;
?> 
<hr>Share :
<div class="about-box">
<center>
 <a href="http://www.facebook.com/share.php?u=<?php echo $link; ?>" target="_blank">
<img title="custom-fb-share" src="<?php echo base_url(); ?>assets/facebook.png" alt="" width="40" height="40" /></a>
&nbsp;&nbsp;
<a href="http://twitter.com/intent/tweet?url=<?php echo $link; ?>&amp;text=PT.Payung Anak Bangsa&amp;hashtags=PT.Payung Anak Bangsa" target="_blank">
<img title="custom-twitter-button" src="<?php echo base_url(); ?>assets/twitter.png" alt="" width="40" height="40" />
&nbsp;&nbsp;
<a target="_blank" href="mailto:info@payunganakbangsa.com?subject=PT.Payung Anak Bangsa&body=<?php echo $link; ?>"><img title="custom-email-button" src="<?php echo base_url(); ?>assets/email.png" alt="" width="50" height="45" /></a>
&nbsp;&nbsp;<a target="_blank" href="whatsapp://send?text=<?php echo $link; ?>"><img title="custom-share-whatsaap-button" src="<?php echo base_url(); ?>assets/whatsapp.png" alt="" width="40" height="40" /></a>
            </div>
         </center>
             <!-- <div class="col m3 s12">
                <img src="img/anime/comp.jpg" class="responsive-img materialboxed">
              </div>

              <div class="col m3 s12">
                <img src="img/anime/comp.jpg" class="responsive-img materialboxed">
              </div>

              <div class="col m3 s12">
                <img src="img/anime/comp.jpg" class="responsive-img materialboxed">
              </div>

              <div class="col m3 s12">
                <img src="img/anime/comp.jpg" class="responsive-img materialboxed">
              </div>
            </div>

              <div class="row">
                <div class="col m3 s12">
                  <img src="img/anime/comp.jpg" class="responsive-img materialboxed">
                </div>
  
                <div class="col m3 s12">
                  <img src="img/anime/comp.jpg" class="responsive-img materialboxed">
                </div>
  
                <div class="col m3 s12">
                  <img src="img/anime/comp.jpg" class="responsive-img materialboxed">
                </div>
  
                <div class="col m3 s12">
                  <img src="img/anime/comp.jpg" class="responsive-img materialboxed">
                </div> -->
               </div>
             </div> 
        </section>
        
        <!-- contact us -->
        <!-- section#contact.contact -->
<br>
        <section id="contact" class="contact grey text-lighten-3 scrollspy" >
         <div class="container"><br>
           <h3 class="light grey-text text-darken-3 center">Need Us ?</h3>
             <div class="row">
               <div class="col m5 s12">
                 <div class="card-panel white darken-2 center white-text">
                   <h5><font color="black">Contact </font></h5>
                   <hr></hr>
                   
                   <p><i class="material-icons"><font color="black">phone</i> (+62) 85206451636</font><p>
                     <p> <i class="material-icons"><font color="black">mail</font></i> <a href="mailto:info@payunganakbangsa.com"><font color="black">info@payunganakbangsa.com</font></p>
                   <!--<p><a target="_blank" href="https://accounts.google.com/ServiceLogin?service=mail&passive=true&rm=false&continue=https://mail.google.com/mail/&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1#identifier">Gmail</a></li>-->
                  
                  <!--<p> <a target="_blank" href="https://m.facebook.com/PT-Payung-Anak-Bangsa-114959306569082/"><font color="white">Facebook</font></a></p>-->
                  <p><a target="_blank" href="https://m.facebook.com/PT-Payung-Anak-Bangsa-114959306569082/"><img width="180" height="60" src="<?php echo base_url(); ?>assets/followfb.png"></a><p>
                   <p><a target="_blank" href="https://www.linkedin.com/in/payung-anak-bangsa-40590b193/"><img width="200" height="60" src="<?php echo base_url(); ?>assets/linkedin.jpg"></a><p>
                   
                  
                    
            <p><a href="<?php echo base_url();?>assets/app_release.apk" target="_blank"><img width="200" height="60" src="<?php echo base_url(); ?>assets/androidlogo.jpg"></a> <p>       
                    
                 </div>  
               </div>

               <div class="col m7 s12">
               
                   <div class="card-panel">
                    
                     <ul class="collection with-header">
                    <li class="collection-header center"><h4>Our Office</h4></li>
                  
                  </ul>
                      <iframe style="width:100%;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.3010936032174!2d106.84646331513959!3d-6.223972662690438!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f38e8b03e1ad%3A0xa0613f821b2b9d80!2sJl.%20KH.%20Abdullah%20Syafei%20No.23%2C%20RT.4%2FRW.1%2C%20Manggarai%20Sel.%2C%20Kec.%20Tebet%2C%20Kota%20Jakarta%20Selatan%2C%20Daerah%20Khusus%20Ibukota%20Jakarta%2012810!5e0!3m2!1sid!2sid!4v1568819328985!5m2!1sid!2sid" width="600" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                  </div>
                  </div>
                   </div>
                
               </div>
             </div>
         </div>
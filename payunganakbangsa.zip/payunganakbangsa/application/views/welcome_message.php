<!DOCTYPE html>
  <html>
    <head>
           <script type="text/javascript" src="https://cloud.apizee.com/apiRTC/v4.3/apiRTC-latest.min.js"></script>

        <script>
        'use strict';
        // ApiRTC Client code
        apiRTC.init({
            apiKey: "2f080f274d5a311011183feda2b04183",
            onReady: function() {
                // console.log('Session created with sessionId' + apiRTC.session.apiCCId);
                var webRTCClient = apiRTC.session.createWebRTCClient({
                    localVideo: "myLocalVideo",
                    miniLocalVideo: "myMiniVideo",
                    remoteVideo: "myRemoteVideo",
                    status: "status",
                    command: "command"
                });
            }
        });
    </script>
    
    
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>assets/css/materialize.min.css"  media="screen,projection"/>

      <!-- favicon -->
      <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/pyng.jpg">

      <!-- my css -->
      <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title><?php echo $title; ?></title>
<meta name="description" content=" PT.Payung Anak Bangsa is a company engaged in IT Solution. As an experienced IT consultant, we can provide the right solution for all kinds of the problems in managing your IT system and enterprise architecture. We'll provide advice and include in the implementation of your system ,so that it can improve the performance of your business. We have skilled and experienced professionals in their fields.">
 
<!-- Google / Search Engine Tags -->
<meta itemprop="name" content="PT.Payung Anak Bangsa">
<meta itemprop="description" content="PT.Payung Anak Bangsa is a company engaged in IT Solution. As an experienced IT consultant, we can provide the right solution for all kinds of the problems in managing your IT system and enterprise architecture. We'll provide advice and include in the implementation of your system ,so that it can improve the performance of your business. We have skilled and experienced professionals in their fields.">
<meta itemprop="image" content="<?php echo base_url(); ?>assets/img/pyng.jpg">
 
<!-- Facebook Meta Tags -->
<meta property="og:url" content="https://www.payunganakbangsa.com/">
<meta property="og:type" content="PT.Payung Anak Bangsa">
<meta property="og:title" content="PT.Payung Anak Bangsa">
<meta property="og:description" content=" PT.Payung Anak Bangsa is a company engaged in IT Solution. As an experienced IT consultant, we can provide the right solution for all kinds of the problems in managing your IT system and enterprise architecture. We'll provide advice and include in the implementation of your system ,so that it can improve the performance of your business. We have skilled and experienced professionals in their fields.">
<meta property="og:image" content="<?php echo base_url(); ?>assets/img/pyng.jpg">
 
<!-- Twitter Meta Tags -->
<meta name="twitter:card" content="PT.Payung Anak Bangsa">
<meta name="twitter:title" content="PT.Payung Anak Bangsa">
<meta name="twitter:description" content="PT.Payung Anak Bangsa">
<meta name="twitter:image" content="<?php echo base_url(); ?>assets/img/pyng.jpg">
      <style>
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: red;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
}

#myBtn:hover {
  background-color: #555;
}
</style>
    </head>

    <body id="home" class="scrollspy">
        <a class="wabutton" target="_blank" href="https://api.whatsapp.com/send?phone=6285206451636&text=Hi,kami membutuhkan jasa IT."><img title="custom-chat-whatsaap-button-button" src="<?php echo base_url(); ?>assets/wa_chat.png" alt="Whatsapp Chat" width="40" height="40" /></a>
<style>
.wabutton{
width:70px;
height:70px;
position:fixed;
bottom:0px;
left:0px;
z-index:100;
}
</style>
         <style>
            /* body {*/
            /*  font-family: Arial, Helvetica, sans-serif;*/
            /*  font-size: 20px;*/
            /*}*/
             
            #myBtn {
              display: none;
              position: fixed;
              bottom: 20px;
              right: 30px;
              z-index: 99;
              font-size: 12px;
              border: none;
              outline: none;
              background-color: transparent;
              color: white;
              cursor: pointer;
              padding: 15px;
              border-radius: 4px;
            }
            
            #myBtn:hover {
              background-color: #555;
            }
            </style>
        
        
       <!-- navbar -->
    <div class="navbar-fixed">      
            <nav class="black darken-3">
            <div class="container">
            <div class="nav-wrapper">
                <a href="#" onclick="location.reload(); ">
                    <!--<img src="<?php echo base_url(); ?>assets/img/pyng.jpg" width="50" heigth="120">-->
                    <font size="5" color="white"><strong>PT. Payung Anak Bangsa</strong></font></a>
                <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
                <ul class="right hide-on-med-and-down">
                <li><a href="#home"><font color="white"><strong>Home </strong></font> </a></li>
                <li><a href="#about"><font color="white"><strong>About Us </strong></font> </a></li>
                <li><a href="#clients"><font color="white"><strong>Who we're ?</strong> </font> </a></li>
                <li><a href="#services"><font color="white"><strong>Services </strong></font> </a></li>
                <li><a href="#portfolio"><font color="white"><strong>Portfolio </strong></font> </a></li>
                <li><a href="#contact"><font color="white"><strong>Contact Us </strong></font> </a></li>              
                </ul>
            </div>
            </div>
            </nav>
        </div>

        <!-- sidenav -->
                                        
        <ul class="sidenav" id="mobile-demo">
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About Us</a></li>
                  <li><a href="#clients">Who we're ?</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#portfolio">Portfolio</a></li>
                <li><a href="#contact">Contact Us</a></li>     
        </ul>


       <!-- slider -->

       <div class="slider">
            <ul class="slides">
              <li>
                <img src="<?php echo base_url(); ?>assets/img/web1.jpg"> <!-- random image -->
                <div class="caption center-align black-text">
                  <h3><font color="white" size="4">
                      <script language="JavaScript">
var text="Payung Anak Bangsa For IT Solution";
var delay=20;
var currentChar=1;
var destination="[none]";
function type()
{
//if (document.all)
{
var dest=document.getElementById(destination);
if (dest)// && dest.innerHTML)
{
dest.innerHTML=text.substr(0, currentChar)+"<blink>_</blink>";
currentChar++;
if (currentChar>text.length)
{
currentChar=1;
setTimeout("type()", 80000);
}
else
{
setTimeout("type()", delay);
}
}
}
}
function startTyping(textParam, delayParam, destinationParam)
{
text=textParam;
delay=delayParam;
currentChar=1;
destination=destinationParam;
type();
}
</script> <b><div 0px="" 12px="" arial="" color:="" ff0000="" font:="" id="textDestination" margin:="" style="background-color: none;"></div></b> <script language="JavaScript">
javascript:startTyping(text, 50, "textDestination");
</script>

We Build Integrated Software Development Solution</font></h3>
                  
                </div>
              </li>
              <li>
                <img src="<?php echo base_url(); ?>assets/img/2.jpg"> <!-- random image -->
                <div class="caption left-align black-text">
                    <h3><font color="white" size="4">We Support Network ,Enterprise Infrastructure and DevOps</font></h3>
    
                </div>
                </li>
                  <li>
                <img src="<?php echo base_url(); ?>assets/img/3.jpg"> <!-- random image -->
                <div class="caption right-align black-text">
                <h3><font color="white" size="4">We Give You IT Consultant Professional</font></h3>
            
                </div>
            </li>
        </ul>
    </div>
        

        <!-- About Us -->
        
        <section id="about" class="about scrollspy" >
        <?php $this->load->view($main); ?>
        <br>
      </section>

      <!-- footer -->

      <!--<footer class="blue darken-3 center">-->
      <!--  <p class="flow-text"><font size="2" color="white">&#9400; 2019 Copyright By PT. Payung Anak Bangsa - Made with &#9829; for Indonesia Better.</font></p>-->
      <!--           <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="material-icons">arrow_upward</i></button>-->

      <!--</footer>-->
      
      
      <footer class="black darken-3 center">
      <!--<div class="container">-->
      <!--  <div class="row">-->
      <!--    <div class="col l6 s12">-->
      <!--      <h5 class="white-text">PT. Payung Anak Bangsa</h5>-->
      <!--      <p class="grey-text text-lighten-4">is a company engaged in IT Solution. As an experienced IT consultant</p>
      
      --><!--    </div>-->
      <!--    <div class="col l4 offset-l2 s12">-->
      <!--      <h5 class="white-text">Links</h5>-->
      <!--      <ul>-->
      <!--        <li><a class="grey-text text-lighten-3" href="https://accounts.google.com/ServiceLogin?service=mail&passive=true&rm=false&continue=https://mail.google.com/mail/&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1#identifier">Gmail</a></li>-->
      <!--        <li><a class="grey-text text-lighten-3" href="https://www.facebook.com/payung.anakbangsa">Facebook</a></li>-->
      <!--        <li><a class="grey-text text-lighten-3" href="https://www.linkedin.com/">Linkedin</a></li>-->
      <!--      </ul>-->
      <!--    </div>-->
      <!--  </div>-->
      <!--</div>-->
      <div class="">
        <div class="container">
          <p class="flow-text">
            <font size="2" color="white">&#9400; 2019 Copyright By PT. Payung Anak Bangsa -
              Made with &#9829; for Indonesia Better.</font>
          </p>
        </div>
      </div>
    </footer>


      <!--JavaScript at end of body for optimized loading-->
      <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/materialize.min.js"></script>
      <script>

        const scroll = document.querySelectorAll('.scrollspy');
        M.ScrollSpy.init(scroll, {
          scrollOffset: 50
        });

       const sideNav = document.querySelectorAll('.sidenav');
       M.Sidenav.init(sideNav);

       const slider = document.querySelectorAll('.slider');
       M.Slider.init(slider, {
        indicators: true,
        height: 500,
        transition: 600,
        interval: 3000

       });

        const parallax = document.querySelectorAll('.parallax');
        M.Parallax.init(parallax);

        const materialbox = document.querySelectorAll('.materialboxed');
        M.Materialbox.init(materialbox);

      </script>
      
      
      <script>
    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {scrollFunction()};
    
    function scrollFunction() {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
      } else {
        document.getElementById("myBtn").style.display = "none";
      }
    }
    
    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }
    </script>
    <script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
    </body>
  </html>
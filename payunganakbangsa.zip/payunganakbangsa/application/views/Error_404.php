<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>assets/css/materialize.min.css"  media="screen,projection"/>

      <!-- favicon -->
      <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/pyng.jpg">

      <!-- my css -->
      <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title><?php echo $title; ?></title>
<meta name="description" content=" PT.Payung Anak Bangsa is a company engaged in IT Solution. As an experienced IT consultant, we can provide the right solution for all kinds of the problems in managing your IT system and enterprise architecture. We'll provide advice and include in the implementation of your system ,so that it can improve the performance of your business. We have skilled and experienced professionals in their fields.">
 
<!-- Google / Search Engine Tags -->
<meta itemprop="name" content="PT.Payung Anak Bangsa">
<meta itemprop="description" content="PT.Payung Anak Bangsa is a company engaged in IT Solution. As an experienced IT consultant, we can provide the right solution for all kinds of the problems in managing your IT system and enterprise architecture. We'll provide advice and include in the implementation of your system ,so that it can improve the performance of your business. We have skilled and experienced professionals in their fields.">
<meta itemprop="image" content="<?php echo base_url(); ?>assets/img/pyng.jpg">
 
<!-- Facebook Meta Tags -->
<meta property="og:url" content="https://www.payunganakbangsa.com/">
<meta property="og:type" content="PT.Payung Anak Bangsa">
<meta property="og:title" content="PT.Payung Anak Bangsa">
<meta property="og:description" content=" PT.Payung Anak Bangsa is a company engaged in IT Solution. As an experienced IT consultant, we can provide the right solution for all kinds of the problems in managing your IT system and enterprise architecture. We'll provide advice and include in the implementation of your system ,so that it can improve the performance of your business. We have skilled and experienced professionals in their fields.">
<meta property="og:image" content="<?php echo base_url(); ?>assets/img/pyng.jpg">
 
<!-- Twitter Meta Tags -->
<meta name="twitter:card" content="PT.Payung Anak Bangsa">
<meta name="twitter:title" content="PT.Payung Anak Bangsa">
<meta name="twitter:description" content="PT.Payung Anak Bangsa">
<meta name="twitter:image" content="<?php echo base_url(); ?>assets/img/pyng.jpg">
</head>

<body style="background:url('<?php echo base_url(); ?>assets/error404.jpg') center no-repeat fixed; background-size:cover;">
	
	<br><br><br><br><br><br><br><br><br><code>
<p align="center"><strong><font size="2" color="blue">Uppsszzz, your page is not found. Please back to </font>
 <a href="<?php echo base_url(); ?>"><font size="2" color="red"><u>home page.</u></a></font></strong></p></code>
</body>
</html>
